package com.demo.ecommercedemoapp.viewmodels

import android.widget.ImageView
import androidx.databinding.BaseObservable
import androidx.databinding.BindingAdapter
import com.bumptech.glide.Glide
import com.demo.ecommercedemoapp.R

import com.demo.ecommercedemoapp.data.datamodels.ProductDetail

class ProductItemViewModel(val productDetail: ProductDetail) : BaseObservable() {

    fun getProductName(): String {
        return productDetail.name
    }

    fun getProductPrice(): String {
        return productDetail.price.toString()
    }

    fun getProductRating(): String {
        return productDetail.rating.toString()
    }


    fun getImageUrl(): String {
        return productDetail.image
    }

    @BindingAdapter("imageUrl")
    fun loadImage(imageView: ImageView,imageUrl:String){
        Glide
            .with(imageView.context)
            .load(imageUrl)
            .placeholder(R.drawable.ic_launcher_background)
            .into(imageView);


    }

}