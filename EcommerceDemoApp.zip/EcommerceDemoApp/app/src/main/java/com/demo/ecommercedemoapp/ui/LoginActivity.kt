package com.demo.ecommercedemoapp.ui

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import com.demo.ecommercedemoapp.R
import com.demo.ecommercedemoapp.data.datamodels.Status
import com.demo.ecommercedemoapp.viewmodels.LoginViewModel
import kotlinx.android.synthetic.main.activity_login.*

class LoginActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)
        val loginViewModel = ViewModelProvider(this).get(LoginViewModel::class.java)

        loginViewModel.checkUserLoggedIn().observe(this, Observer { user ->
            if (user != null) {
                val intent = Intent(this, ProductListActivity::class.java)
                intent.putExtra("authToken",user.customer_token)
                startActivity(intent)
            }

        })
        loginViewModel.loginUser.observe(this, Observer { serverRes ->
            when (serverRes.status) {
                Status.SUCCESS -> {
                    Toast.makeText(this, serverRes.data?.message, Toast.LENGTH_SHORT).show()


                }
                Status.ERROR -> {
                    Toast.makeText(this, serverRes.message, Toast.LENGTH_SHORT).show()
                }
                Status.LOADING -> {
                    Toast.makeText(this, serverRes.message, Toast.LENGTH_SHORT).show()
                }
            }

        })

        loginButton.setOnClickListener {
            val email: String = userNameET.text.toString()
            val password: String = passwordET.text.toString()
            loginViewModel.loginWithCredentials(email, password)
        }


    }
}