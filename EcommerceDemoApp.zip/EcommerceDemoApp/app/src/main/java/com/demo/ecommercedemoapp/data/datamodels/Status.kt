package com.demo.ecommercedemoapp.data.datamodels

enum class Status {
    SUCCESS,
    ERROR,
    LOADING
}