package com.demo.ecommercedemoapp.data.repository

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.demo.ecommercedemoapp.data.ProductDetailDao
import com.demo.ecommercedemoapp.data.datamodels.CategoryData
import com.demo.ecommercedemoapp.data.datamodels.CategoryId
import com.demo.ecommercedemoapp.data.datamodels.FilterData
import com.demo.ecommercedemoapp.data.datamodels.ProductDetail
import com.demo.ecommercedemoapp.data.networking.ApiInterface
import com.demo.ecommercedemoapp.data.networking.getNetworkApiService

class ProductRepository(val productDetailDao: ProductDetailDao,authToken:String) {

    val apiInterface: ApiInterface
    private val TAG = ProductRepository::class.java.simpleName


    init {
        apiInterface = getNetworkApiService(authToken)
    }

    suspend fun getAllProducts(): LiveData<List<ProductDetail>> {
        val productList = MutableLiveData<List<ProductDetail>>()
        try {
            productList.value = getAllProductsFromDb()
        } catch (e: Exception) {
            Log.i(TAG, "getAllProductsFromDb >>" + e.localizedMessage)
        }
        try {
            val serverResponse = getAllProductsFromServer()
            productList.value = serverResponse.products

            try {
                productDetailDao.insertProducts(serverResponse.products)
            } catch (e: Exception) {
                Log.i(TAG, "insertProducts >>" + e.localizedMessage)
            }

        } catch (e: Exception) {
            Log.i(TAG, "getAllProductsFromServer >>" + e.localizedMessage)
        }

        return productList
    }


    private suspend fun getAllProductsFromDb() = productDetailDao.getProducts()

    private suspend fun getAllProductsFromServer() = apiInterface.getAllProducts(FilterData(CategoryData(CategoryId())))
}