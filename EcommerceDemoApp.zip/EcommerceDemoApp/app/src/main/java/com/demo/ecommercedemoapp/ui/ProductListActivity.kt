package com.demo.ecommercedemoapp.ui

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import com.demo.ecommercedemoapp.R
import com.demo.ecommercedemoapp.adapter.ProductListAdapter
import com.demo.ecommercedemoapp.data.datamodels.ProductDetail
import com.demo.ecommercedemoapp.viewmodels.ProductListModel
import kotlinx.android.synthetic.main.activity_main.*


class ProductListActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val productListModel = ViewModelProvider(this).get(ProductListModel::class.java)

        val authToken = intent.getStringExtra("authToken") ?: ""
        productListModel.authToken = authToken

        productListModel.getAllProducts().observe(this, Observer {
            if (it.isNotEmpty()) {
                val productList = ArrayList<ProductDetail>()
                productList.addAll(it)
                reccylerView.adapter = ProductListAdapter(productList)
            }

        })

    }
}