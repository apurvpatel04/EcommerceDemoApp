package com.demo.ecommercedemoapp.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.demo.ecommercedemoapp.data.datamodels.ProductDetail
import com.demo.ecommercedemoapp.databinding.ItemProductDetailListBinding
import com.demo.ecommercedemoapp.viewmodels.ProductItemViewModel

class ProductListAdapter(val productList: ArrayList<ProductDetail>) :
    RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        val binding = ItemProductDetailListBinding.inflate(inflater)
        return ProductListViewHolder(binding)
    }

    override fun getItemCount(): Int {
       return productList.size
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        if (holder is ProductListViewHolder) {
            holder.bind(productList.get(position))
        }
    }

    internal inner class ProductListViewHolder(val binding: ItemProductDetailListBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(product: ProductDetail) {
            binding.product = ProductItemViewModel(product)
        }
    }

}