package com.demo.ecommercedemoapp.viewmodels

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.demo.ecommercedemoapp.data.ProductRoomDataBase
import com.demo.ecommercedemoapp.data.datamodels.LoginUser
import com.demo.ecommercedemoapp.data.datamodels.ProductDetail
import com.demo.ecommercedemoapp.data.datamodels.ServerResponse
import com.demo.ecommercedemoapp.data.repository.LoginRepository
import com.demo.ecommercedemoapp.data.repository.ProductRepository
import kotlinx.coroutines.launch

class ProductListModel(application: Application):AndroidViewModel(application) {

    private val TAG = ProductListModel::class.java.simpleName
    private val productRepository:ProductRepository
    var authToken = ""

    init {
        val productDetailDao = ProductRoomDataBase.getDatabase(application).productDetailDao()
        productRepository = ProductRepository(productDetailDao,authToken)
    }




    fun getAllProducts(): LiveData<List<ProductDetail>> {
        val productList = MutableLiveData<List<ProductDetail>>()
        viewModelScope.launch {
            productList.value = productRepository.getAllProducts().value

        }

        return productList
    }



}