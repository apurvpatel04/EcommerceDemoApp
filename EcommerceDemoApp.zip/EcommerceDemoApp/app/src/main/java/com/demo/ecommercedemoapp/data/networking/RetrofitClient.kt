package com.demo.ecommercedemoapp.data.networking


import com.demo.ecommercedemoapp.data.datamodels.FilterData
import com.demo.ecommercedemoapp.data.datamodels.LoginUser
import com.demo.ecommercedemoapp.data.datamodels.ProductApiRes
import com.demo.ecommercedemoapp.data.datamodels.ProductDetail
import okhttp3.Interceptor
import okhttp3.OkHttpClient
import okhttp3.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.Body
import retrofit2.http.POST
import retrofit2.http.Query


fun getNetworkApiService(authToken: String): ApiInterface {


    val okHttpClientBuilder = OkHttpClient.Builder()


    if (authToken.isNotEmpty()){
        val interceptor = AuthenticationInterceptor(authToken)
        okHttpClientBuilder.addInterceptor(interceptor)
    }
    val okHttpClient = okHttpClientBuilder.build()


    val retrofit = Retrofit.Builder()
        .baseUrl("https://specops-qa.solution.magentoprojects.net/rest/specops/V1/")
        .client(okHttpClient)
        .addConverterFactory(GsonConverterFactory.create())
        .build()

    return retrofit.create(ApiInterface::class.java)
}

class AuthenticationInterceptor(val authToken: String) : Interceptor {


    override fun intercept(chain: Interceptor.Chain): Response {
        val requestBuilder = chain.request().newBuilder()
       // requestBuilder.addHeader("Authorization", "Bearer $authToken")
        requestBuilder.addHeader("Content-Type", "application/json");
        return chain.proceed(requestBuilder.build())
    }
}

interface ApiInterface {

    @POST("customer/customerlogin")
    suspend fun loginApi(
        @Query("email") email: String,
        @Query("password") password: String
    ): LoginUser

    @POST("category/products")
    suspend fun getAllProducts(@Body filterData: FilterData): ProductApiRes

}