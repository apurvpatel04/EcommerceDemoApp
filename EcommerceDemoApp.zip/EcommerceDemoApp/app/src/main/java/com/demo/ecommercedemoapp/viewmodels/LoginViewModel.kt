package com.demo.ecommercedemoapp.viewmodels

import android.app.Application
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.demo.ecommercedemoapp.data.ProductRoomDataBase
import com.demo.ecommercedemoapp.data.datamodels.LoginUser
import com.demo.ecommercedemoapp.data.datamodels.ServerResponse
import com.demo.ecommercedemoapp.data.datamodels.Status
import com.demo.ecommercedemoapp.data.networking.getNetworkApiService
import com.demo.ecommercedemoapp.data.repository.LoginRepository
import kotlinx.coroutines.launch


class LoginViewModel(application: Application) : AndroidViewModel(application) {
    val loginUser = MutableLiveData<ServerResponse<LoginUser>>()
    private val TAG = LoginViewModel::class.java.simpleName
private val loginRepository:LoginRepository

    init {
        val loginUserDao = ProductRoomDataBase.getDatabase(application).loginUserDao()
        loginRepository = LoginRepository(loginUserDao)
    }

    fun loginWithCredentials(email: String, password: String) {
        viewModelScope.launch {
            try {

                loginUser.value = ServerResponse(Status.LOADING, null, "Please Wait")
                val response = loginRepository.loginWithCredentials(email, password)
                loginUser.value = ServerResponse(Status.SUCCESS, response, response.message)
                try {
                    loginRepository.insertLoggedInUser(response)
                }catch (e:Exception){
                    Log.i(TAG,"User Not Inserted>>"+e.localizedMessage)
                }


            } catch (error: Exception) {
                loginUser.value = ServerResponse(Status.ERROR, null, "Login Failed")
            }
        }
    }


     fun checkUserLoggedIn():LiveData<LoginUser>{
        val logedInUser = MutableLiveData<LoginUser>()
        viewModelScope.launch {
            try {
                val user = loginRepository.getLoggedInUser()
                if (user.isNotEmpty()){
                    logedInUser.value =user.get(0)
                }

            }catch (error:Exception){
                Log.i(TAG,"checkUserLoggedIn >>"+error.localizedMessage)
                logedInUser.value = null
            }

        }
        return logedInUser
    }

}